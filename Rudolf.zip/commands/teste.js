const Discord = require("discord.js");

module.exports.run = async (client, message, args) => {

await message.channel.send("Mensagem foi enviada na sua DM")

const embed = new Discord.MessageEmbed()
.setColor("#ffd700")
.setTitle('Aki será o titulo')
.setDescription(`Aki será a descrição`)


message.author.send(embed);

}