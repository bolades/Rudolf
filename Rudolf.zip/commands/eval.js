const Discord = require('discord.js')

module.exports.run =  async (client, message, args, botcolor) => {
          if(message.author.id == '722809107408486471' || message.author.id == '681432978743623690') {
            try {
              const code = args.join(" ");
              let evaled = eval(code);
              const embed = new Discord.MessageEmbed()
                      .setColor(botcolor)
                      .setTitle('Eval')
                      .addFields(
                         {name: ':computer: Entrada', value:`\`${code} \``},
                         { name: ' :desktop: Saida', value: `\` ${evaled} \``},
                    )
                      .setTimestamp()
                      .setFooter(message.author.tag + ' | Eval')

                    message.quote(`<@${message.author.id}>`, embed);
            } catch (err) {
              message.quote(`\`ERROR\` \`\`\`js\n${err}\n\`\`\``);
          }
          }
          else {
               return message.quote( `<@${message.author.id}>`,
              new Discord.MessageEmbed()
                .setDescription('**:white_check_mark:・Forma de se utilizar:**\n`p.eval [valor]`\n\n**:585767366743293952:・Exemplo:**\n`p.eval message.channel.send("Oi")`\n\n**:regras:・Permissões:**\n`Ser o Dono do bot`')
                .setColor(botcolor)
                .setFooter('<> Argumento Opcional | [] Argumento obrigatório')
                .setTitle('Ocorreu um Erro!')
            )
          }
};