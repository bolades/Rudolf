const Discord = require('discord.js');

module.exports = {
    name: "store",
    description: "View the store",

    async run (client, message, args) {

        const embed = new Discord.MessageEmbed()
        .setTitle('Loja')
        .setDescription(`Carro - 500 moeda \n Relógio - 250 moedas`)
        .setTimestamp();

        message.channel.send(embed);
    }
}