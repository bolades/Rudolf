const db = require('quick.db');
const Discord = require('discord.js');

module.exports = {
    name: "buy",
    description: "Buy an item from the store",

    async run (client, message, args) {
        let purchase = args.join(" ");
        if(!purchase) return message.channel.send('Por favor diga um item para comprar')
        let items = await db.fetch(message.author.id, { items: [] });
        let amount = await db.fetch(`money_${message.guild.id}_${message.author.id}`)

        if(purchase === 'carro' || 'Carro'){
            if(amount < 500) return message.channel.send('Não tens dinheiro suficiente para comprar isto. Tenta outro item');
            db.subtract(`money_${message.guild.id}_${message.author.id}`, 500);
            db.push(message.author.id, "Carro");
            message.channel.send('Compras-te esse item com sucesso')
        }
        if(purchase === 'relógio' || 'relógio'){
            if(amount < 250) return message.channel.send('Não tens dinheiro suficiente para comprar isto. Tenta outro item');
            db.subtract(`money_${message.guild.id}_${message.author.id}`, 250);
            db.push(message.author.id, "relógio");
            message.channel.send('Compras-te esse item com sucesso')
        }
    }
}