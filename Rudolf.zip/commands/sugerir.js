const { MessageEmbed } = require("discord.js")


module.exports = {
  name: "Sugerir",
  usage: "Sugerir <mensagem>",
  description: "Manda a tua sugestão",
  category: "main",
  run: (client, message, args) => {
    
    if(!args.length) {
      return message.channel.send("Por favor dê uma sugestão")
    }
    
    let channel = message.guild.channels.cache.find((x) => (x.name === "sυgєsτõєs" || x.name === "sυgєsτõєs"))
    
    
    if(!channel) {
      return message.channel.send("Não existe nenhum canal chamado - sυgєsτõєs")
    }
                                                    
    
    let embed = new MessageEmbed()
    .setAuthor("SUGESTÃO: " + message.author.tag, message.author.avatarURL())
    .setThumbnail(message.author.avatarURL())
    .setColor("#ff2050")
    .setDescription(args.join(" "))
    .setTimestamp()
    
    
    channel.send(embed).then(m => {
      m.react("✅")
      m.react("❌")
    }).catch(err => {})
    

    
    message.channel.send("Sugestão mandada para sυgєsτõєs").catch(err => {})
    
  }
}