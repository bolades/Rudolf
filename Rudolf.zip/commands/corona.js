    const discord = require("discord.js")
    const fetch = require("node-fetch")
    
    module.exports = {
        config: {
            title: "Corona",
            name: "corona",
            aliases: ['corona'],
            descripition: "Mostra corona!",
            usage: "r!corona"
        },
      run: async (client, message, args) => {
    
    let msg = await message.channel.send({
      embed: {
        "description": "Pegando Informações...",
        "color": "YELLOW"
      }
    })
        
       
        if(!args[0] || args[0].toLowerCase() === "all" || args[0].toLowerCase() === "global") {
           try {
          let corona = await fetch("https://disease.sh/v3/covid-19/all")
          corona = await corona.json()
          
          let embed = new discord.MessageEmbed()
          .setTitle(`${corona.country.toUpperCase()}`)
          .setColor("GREEN")
          .setThumbnail(corona.countryInfo.flag || "")
          .addField("Casos totais", corona.cases, true)
          .addField("Total de mortes", corona.deaths, true)
          .addField("Total recuperado", corona.recovered, true)
          .addField("Casos de hoje", corona.todayCases, true)
          .addField("Mortes de hoje", corona.todayDeaths, true)
          .addField("Casos ativos", corona.active, true);
          
         
          return msg.edit(embed)
          } catch(err) {
        
        msg.edit({embed: {
          
          "description": "Algo deu errado...",
          "color": "RED"
        }})
      }
          
          
        } else {
    
           try {
    
          let corona = await fetch(`https://disease.sh/v3/covid-19/countries/${args.join(" ")}`)
          corona = await corona.json()
          
          let embed = new discord.MessageEmbed()
          .setTitle(`${corona.country.toUpperCase()}`)
          .setColor("GREEN")
          .setThumbnail(corona.countryInfo.flag || "")
          .addField("Casos totais", corona.cases, true)
          .addField("Total de mortes", corona.deaths, true)
          .addField("Total recuperado", corona.recovered, true)
          .addField("Casos de hoje", corona.todayCases, true)
          .addField("Mortes de hoje", corona.todayDeaths, true)
          .addField("Casos ativos", corona.active, true);
          
          return msg.edit(embed)
    
          } catch(err) {
        
        msg.edit({embed: {
          
          "description": "Não foi possivel achar esse país!",
          "color": "RED"
        }})
      }
          
          
        }
        
      
    
      }
    }