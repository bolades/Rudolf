const Discord = require('discord.js')

module.exports.run = async (bot, message, args) => {
  const embed = new Discord.MessageEmbed()
    .setTitle('Help')
    .setURL('')
    .setAuthor('Rudolf')
    .setDescription('')
    .setColor('#FF2D00')
    .setThumbnail('https://cdn.discordapp.com/avatars/773861953852276766/a3de2d68d23c8fd5308c4c0ee019b7db.png?size=1024')
    .setImage('')
    .setFooter('Bot feito, pelo Sábio', 'https://cdn.discordapp.com/avatars/681432978743623690/5fe3d233171433a3c69df3a7f5dd9a22.png?size=1024')
    .addFields(
      { name: '**💠・Membros**', value: '`help` | `serverinfo` | `userinfo`' },
      { name: '**😎・Diversão**', value: '`coinflip(cara/coroa)` | `avatar` | `tempo(cidade)` | `corona(país)`'},
      { name: '**🎭・Roleplay**', value: '`hug` | `kiss` | `kill`'},
      { name: '**💰・Economia**', value: '`daily` | `work` | `bal` | `buy` | `loja` | `inventário`'},
      { name: '**<:staff:785553230960656425>・Administração**', value: '`clear` | `ban` | `kick`'},
      { name: '**<:585763690868113455:784519631318417449>・Bot**', value: '`botinfo` | `invite` | `ping` | `uptime`'},
    )
    .setTimestamp()


  message.channel.send(embed);
}

module.exports.config = {
  name: "teste",
  description: "teste",
  usage: "teste",
  accessableby: "Members",
  aliases: []
}