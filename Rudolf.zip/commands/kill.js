const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
  'https://cdn.zerotwo.dev/SHOOT/56887bf7-4857-48d1-bf1e-8b04bf5b272f.gif',
  'https://cdn.zerotwo.dev/SHOOT/49d1a959-5bf9-4ea6-90b1-932bb7b302b9.gif',
  'https://cdn.zerotwo.dev/SHOOT/0465f94f-3ff1-4875-8223-dfdf8043adf0.gif',
  'https://cdn.zerotwo.dev/SHOOT/028bfc32-c06b-4295-87a5-7ddaef08d5ef.gif',
  'https://cdn.zerotwo.dev/SHOOT/d531b121-5bf4-43df-a723-f13e90c370c2.gif',
  'https://cdn.zerotwo.dev/SHOOT/b39598bd-5a18-487a-a5a2-414ea081205c.gif',
  'https://cdn.zerotwo.dev/SHOOT/e420c1f1-2838-45c1-a56c-ca0c16632b42.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para matar!');
}
/*
message.channel.send(`${message.author.username} **acaba de matar** ${user.username}! :heart:`, {files: [rand]});
*/
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('Kill')
        .setColor('#000000')
        .setDescription(`${message.author} acaba de matar ${user}`)
        .setImage(rand)
        .setTimestamp()
        .setThumbnail(avatar)
        .setFooter('Killu Killu Killu')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}