const { MessageEmbed } =  require('discord.js');

module.exports.run = async (client, message, args) => {
    let totalSeconds = client.uptime / 1000;
    let days = Math.floor(totalSeconds / 86400);
    let hours = Math.floor(totalSeconds / 3600);
    totalSeconds %= 3600;
    let minutes = Math.floor(totalSeconds / 60);
    let seconds = totalSeconds % 60;

    let uptime = ` ${days.toFixed()} dias, ${hours.toFixed()} horas, ${minutes.toFixed()} minutos, ${seconds.toFixed()} segundos`;
	  message.quote( `<@${message.author.id}>`,
	   new MessageEmbed()
      		.setColor('RANDOM')
      		.setTitle('Rudolf - Informações')
      		.setDescription(`**Eu fui desenvolvidodo em <:js:783148792228347904>[JavaScript](https://nodejs.org/en/) utilizando <:discordjs:785523300914429982>[Discord.js](https://discord.js.org/#/)**\n\n`)
      		.addField(":file_folder:・Hospedagem: ", '**[Repl](https://repl.it/)**', true)
      		.addField("<:585767366743293952:784519631331131447>・Banco de Dados", "**[quick.db](https://quickdb.js.org/)**", true)
      		.addField("<:developer:784247222534930432>・Equipe:", `<@681432978743623690> e <@722809107408486471> `, true)
      		.addField(":busts_in_silhouette:・Usuários:", client.users.cache.size, true)
      		.addField(":globe_with_meridians:・Servidores:", client.guilds.cache.size, true)
      		.addField("<:585783907841212418:784519631431532595>・canais:", client.channels.cache.size, true)
      		.setThumbnail('https://cdn.discordapp.com/avatars/773861953852276766/a3de2d68d23c8fd5308c4c0ee019b7db.png?size=1024')
      		.setFooter('Bot feito, pelo Sábio', 'https://cdn.discordapp.com/avatars/681432978743623690/7e515ef602f31fb6f678cf5dbc202320.png?size=1024')
	
	)
}