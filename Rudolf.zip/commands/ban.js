const Discord = require("discord.js");
module.exports= {
  name: 'ban',
  category: 'moderation',
  description: 'ban a members',
  run: async(client,message,args,guild) => {
    let banned = message.mentions.users.first() || client.users.resolve(args[0]);
    let reason = args.slice(1).join(" ");
  
    // MESSAGES
  
    if (!banned) {
      let baninfoembed = new Discord.MessageEmbed()
        .setTitle("Command: ban")
        .setDescription(
          `** Descrição: ** Banir um membro, limite de tempo opcional. \n` +
            "** Subcomandos: ** \n" +
            "-ban save | Banir um usuário e salvar suas mensagens no bate-papo. \n" +
            "** Uso: ** \n" +
            "-ban [usuário] (limite) (motivo) \n" +
            "-ban salvar [usuário] (limite) (motivo) \n" +
            "** Exemplos: ** \n" +
            "-ban <@member> 48h spam \n" +
            "-ban save <@member> 48h de spam"
        )
        .setColor("#2C2F33");
      message.channel.send(baninfoembed);
  
      return;
    }
  
    if (message.author === banned) {
      let sanctionyourselfembed = new Discord.MessageEmbed()
        .setDescription(`Você não pode se banir ;-;`)
        .setColor("#2C2F33");
      message.channel.send(sanctionyourselfembed);
  
      return;
    }
  
    if (!reason) {
      let noreasonembed = new Discord.MessageEmbed()
        .setDescription(`Insira um motivo`)
        .setColor("#2C2F33");
      message.channel.send(noreasonembed);
  
      return;
    }
  
    if (!message.member.permissions.has("BAN_MEMBERS")) {
      let nopermsembed = new Discord.MessageEmbed()
        .setDescription(
          "Você não tem permissão para `BAN MEMBERS` contatar um administrador"
        )
        .setColor("#2C2F33");
      message.channel.send(nopermsembed);
  
      return;
    }
  
    if (!message.guild.me.permissions.has("BAN_MEMBERS")) {
      let botnopermsembed = new Discord.MessageEmbed()
        .setDescription(
          "Eu não tenho permissão de `BAN MEMBERS`, entre em contato com um administrador"
        )
        .setColor("#2C2F33");
      message.channel.send(botnopermsembed);
  
      return;
    }
  
    message.guild.members.ban(banned, { reason: reason });
  
    let successfullyembed = new Discord.MessageEmbed()
      .setTitle(`${banned.tag} foi banido com sucesso.`)
      .setColor("#2C2F33");
  
    message.channel.send(successfullyembed);
  }
}
