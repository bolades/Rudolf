const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
  'https://i.imgur.com/r9aU2xv.gif',
  'https://i.imgur.com/wOmoeF8.gif',
  'https://i.imgur.com/nrdYNtL.gif',
  'https://cdn.zerotwo.dev/HUG/dae33024-73d5-43e3-ac9b-8dd4d84985b5.gif',
  'https://cdn.zerotwo.dev/HUG/d856f3fe-f220-41b6-b3c2-f0a2d956dd8a.gif',
  'https://cdn.zerotwo.dev/HUG/f37a37f7-ed68-4742-9538-1d4015111152.gif',
  'https://cdn.zerotwo.dev/HUG/2d59c69c-8df0-4754-a7e4-b568baca1609.gif',
  'https://cdn.zerotwo.dev/HUG/1f646518-d712-4a32-a3e1-0b7f75ec1257.gif',
  'https://cdn.zerotwo.dev/HUG/f3cf9e04-14b4-4620-8918-9dbd35bd25b6.gif',
  'https://cdn.zerotwo.dev/HUG/7e894ee5-4c63-4bd0-b3c9-7e4a53da9604.gif',
  'https://cdn.zerotwo.dev/HUG/897d2eab-c1d9-48f3-8ac9-2bbbf4911cc7.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para abraçar!');
}
/*
message.channel.send(`${message.author.username} **acaba de abraçar** ${user.username}! :heart:`, {files: [rand]});
*/
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('Hug')
        .setColor('#000000')
        .setDescription(`${message.author} acaba de abraçar ${user}`)
        .setImage(rand)
        .setTimestamp()
        .setThumbnail(avatar)
        .setFooter('Hugu hugu hugu')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}