
const Discord = require('discord.js');

const db = require('quick.db')

module.exports = {
    name: "kick",
    description: "Kicks a member from the server",

    async run (client, message, args) {

        if(!message.member.hasPermission("KICK_MEMBERS")) return message.channel.send('Não podes usar isso!')
        if(!message.guild.me.hasPermission("KICK_MEMBERS")) return message.channel.send('Não tenho as permissões necessárias.')

        const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

        if(!args[0]) return message.channel.send('Digite o nome de um usuário.');

        if(!member) return message.channel.send('Não consigo encontrar esse usuário');
        if(!member.kickable) return message.channel.send('Este usuário não pode ser kickado porque tem admin ou tem um cargo mais alto que o meu.');

        if(member.id === message.author.id) return message.channel.send('Não te podes kickar a ti mesmo');

        let reason = args.slice(1).join(" ");

        if(!reason) reason = 'Não especificada';

        member.kick(reason)
        .catch(err => {
            if(err) return message.channel.send('Algo correu mal')
        })

        const kickembed = new Discord.MessageEmbed()
        .setTitle('Membro Kickado')
        .setThumbnail(member.user.displayAvatarURL())
        .addField('Usuário Kickado', member)
        .addField('Kickado por', message.author)
        .addField('Razão', reason)
        .setFooter('Hora', client.user.displayAvatarURL())
        .setTimestamp()

        message.channel.send(kickembed);
    }
}