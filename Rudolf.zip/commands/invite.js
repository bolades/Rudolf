const Discord = require('discord.js');

module.exports.run = async (bot, message, args) => {
  const embed = new Discord.MessageEmbed()
    .setTitle('Convide o Rudolf para o seu servidor')
    .setURL('https://discord.com/api/oauth2/authorize?client_id=773861953852276766&permissions=8&scope=bot')
    .setAuthor('Rudolf')
    .setDescription('')
    .setColor('#13eded')
    .setThumbnail('https://cdn.discordapp.com/avatars/773861953852276766/aba8ce98a36f820e9a3edaa74b43dbca.png?size=1024')
    .setImage('')
    .setFooter('Bot feito, pelo Sábio', 'https://cdn.discordapp.com/avatars/681432978743623690/5fe3d233171433a3c69df3a7f5dd9a22.png?size=1024')
    .setTimestamp()


  message.channel.send(embed);
}

module.exports.config = {
  name: "embed",
  description: "Invite",
  usage: "?embed",
  accessableby: "Members",
  aliases: []
} 