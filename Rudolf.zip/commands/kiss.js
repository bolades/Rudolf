const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
  'https://imgur.com/iclUiUN.gif',
  'https://imgur.com/lYQt9rx.gif',
  'https://imgur.com/w1TU5mR.gif',
  'https://cdn.zerotwo.dev/KISS/dd2bacdb-aece-4c7a-8a6c-4c39af195411.gif',
  'https://cdn.zerotwo.dev/KISS/1a43ff80-a5ca-4e78-929b-09714a51b557.gif',
  'https://cdn.zerotwo.dev/KISS/1afe24ba-5014-4ddd-9222-5969076e9de3.gif',
  'https://cdn.zerotwo.dev/KISS/38c7fa03-f800-463d-ac01-7ad7f70e29e6.gif',
  'https://cdn.zerotwo.dev/KISS/8305fe0d-62c8-42ec-adc3-282fe202e00b.gif',
  'https://cdn.zerotwo.dev/KISS/17d49987-e0fd-47d6-8b9a-dbfa250abb5e.gif',
  'https://cdn.zerotwo.dev/KISS/840f569a-10e9-4ed2-ab73-1066fa580302.gif',
  'https://cdn.zerotwo.dev/KISS/c00a93c6-39ed-4ef1-af7d-1c4a5642e9f5.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para beijar!');
}
/*
message.channel.send(`${message.author.username} **acaba de beijar** ${user.username}! :heart:`, {files: [rand]});
*/
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('Kiss')
        .setColor('#000000')
        .setDescription(`${message.author} acaba de beijar ${user}`)
        .setImage(rand)
        .setTimestamp()
        .setThumbnail(avatar)
        .setFooter('Kissu kissu kissu')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}