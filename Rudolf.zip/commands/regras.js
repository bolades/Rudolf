const Discord = require('discord.js');

module.exports.run = async (bot, message, args) => {
    if (!message.member.permissions.has("MANAGE_MESSAGES"))
    return message.reply(
      "você é fraco, lhe falta permissão de `Gerenciar Mensagens` para usar esse comando"
    )
    
  const embed = new Discord.MessageEmbed()
    .setTitle('Regras')
    .setURL('')
    .setAuthor('')
    .setDescription('')
    .setColor('#FF2D00')
    .setThumbnail('')
    .setImage('')
    .setFooter('Sábio Server', 'https://cdn.discordapp.com/avatars/681432978743623690/5fe3d233171433a3c69df3a7f5dd9a22.png?size=1024')
    .addFields(
      { name: '1', value: 'Flodagem: Não pode flodar. Puniçaõ - Mute(2 dias)' },
      { name: '2', value: 'Bullying: Não aceitamos bullying, tais como xingamentos das pessoas. Punição - Kick' },
      { name: '3', value: 'Convites: Não mandar convites de outros servidores. Punição - Mute' },
      { name: '4', value: 'Nicks: Sem Com nicks ofensivos. Punição - Kick' },
      { name: '5', value: 'Proibido o envio de imagens impróprias.Punição - Ban' },
      { name: '6', value: 'Divulgação: Não toleramos a divulgação de informações pessoais. Punição - Mute (4 dias)' },
      { name: '7', value: 'Convites: Não toleramos os convites para outros grupos sem ter a permissão da staff Punição - Mute'},
      { name: '8', value: 'Comandos: Só usar os comandos em <#715514784203931668>' },
      { name: '9', value: 'Escrever: Não escrever mensagens no <#752894333681926194> só para pedir música' }, 
    )
    .setTimestamp()


  message.channel.send(embed);
}

module.exports.config = {
  name: "embed",
  description: "Help",
  usage: "?embed",
  accessableby: "Members",
  aliases: []
}